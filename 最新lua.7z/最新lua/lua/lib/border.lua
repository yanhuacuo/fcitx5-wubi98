-- border.lua
border_began = '〔'
border_end = '〕'
