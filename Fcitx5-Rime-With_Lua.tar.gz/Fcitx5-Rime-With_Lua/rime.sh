#!/bin/bash

sudo apt install fcitx5-rime librime-plugin-lua -y

if [ -d ~/.local/share/fcitx5/rime ];then
  rm -rf ~/.local/share/fcitx5/rime
fi
  
mkdir -p ~/.local/share/fcitx5/rime/build

sudo rm -rf /usr/share/rime-data
sudo cp -rf ./rime-data /usr/share

rm -rf ~/.local/share/fcitx5/rime/*
cp -rf ./rime-data/* ~/.local/share/fcitx5/rime

echo "中州韻配置文件安置成功，注销一次系统后，在「区域与语言」中添加「汉语」-「rime」即可。"
